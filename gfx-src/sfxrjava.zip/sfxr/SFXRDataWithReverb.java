//
// Copyright (c) 2010 Per Nyblom, Nyblom Software Sweden
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


package sfxr;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;

import freeverb.FreeverbFilter;

public class SFXRDataWithReverb extends SFXRData {

	public double wet1 = 0.5;
	public double wet2 = 0.5;
	public double dry = 0.0;
	public double gain = 0.1;
	public double postAmp = 0.5;
	public double damp = 0.2;
	public double room_size = 0.9;

	FreeverbFilter freeverb;

	public SFXRDataWithReverb(int seed) {
		super(seed);
		freeverb = new FreeverbFilter();
	}

	public void getData(double[] result) {
		double value = synthSample();
		freeverb.getValues(new double[] { value, value }, result);
	}

	@Override
	public void resetSample(boolean restart) {
		super.resetSample(restart);
		if (!restart) {
			freeverb.wet1 = wet1;
			freeverb.wet2 = wet2;
			freeverb.dry = dry;
			freeverb.gain = gain;
			freeverb.postAmp = postAmp;
			freeverb.damp = damp;
			freeverb.room_size = room_size;
			freeverb.buildFilters();
		}
	}

	AudioFormat getStereoAudioFormat() throws Exception {
		AudioFormat result = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED,
				44100.0f, 16, 2, 4, 44100.0f, false);
		return result;
	}

	public void play(int millis) throws Exception {
		AudioFormat stereoFormat = getStereoAudioFormat();
		SourceDataLine stereoSdl = AudioSystem.getSourceDataLine(stereoFormat);

		if (!stereoSdl.isOpen()) {
			try {
				stereoSdl.open();
			} catch (LineUnavailableException e) {
				e.printStackTrace();
			}
		}
		if (!stereoSdl.isRunning()) {
			stereoSdl.start();
		}

		double seconds = millis / 1000.0;
		
		int bufferSize = (int) (4 * 41000 * seconds);

		byte[] target = new byte[bufferSize];

		writeBytes(target);
		stereoSdl.write(target, 0, target.length);
	}

	private void writeBytes(byte[] target) {
		double[] temp = new double[2];
		for (int i = 0; i < target.length / 4; i++) {
			getData(temp);
			writeValueStereo(target, i * 4,
					(short) (temp[0] * (double) Short.MAX_VALUE),
					(short) (temp[1] * (double) Short.MAX_VALUE));
		}
	}

	public static void writeValueStereo(byte[] target, int position,
			short value1, short value2) {
		target[position] = (byte) (value1 & 0x00ff);
		target[position + 1] = (byte) ((value1 & 0xff00) >> 8);
		target[position + 2] = (byte) (value2 & 0x00ff);
		target[position + 3] = (byte) ((value2 & 0xff00) >> 8);
	}

	public static void main(String[] args) throws Exception {
		SFXRDataWithReverb data = new SFXRDataWithReverb(10);
		data.random(23);
		data.postAmp = 0.2;
		data.wet1 = 0.2;
		data.wet2 = 0.0;
		data.dry = 0.7;
		data.resetSample(false);
		int millisToPlay = 3000;
		data.play(millisToPlay);
		Thread.sleep(1000);
		System.exit(0);
	}

}
