//
// Copyright (c) 2010 Per Nyblom, Nyblom Software Sweden
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


package freeverb;


public class LTIFilter extends Filter {

	static class LTIFilterCoeffs {
		double[] ff; // Feed forward
		double[] fb; // Feed backward
	}

	double[] feedForwardCoeffs; // Input coeffs
	double[] feedBackwardCoeffs; // Recursive coeffs (omits the coefficient
	// for y[n], i.e. the first is for y[n-1])
	double[] inputMemory;
	double[] outputMemory;

	int inputWritePointer = 0;
	int outputWritePointer = 0;

	public LTIFilter() {
	}

	// diff equation: y[n] = ff[0] * x[0] + ff[1] * x[1] + ... + fb[1] * y[n-1]
	// + fb[2] * y[n-2] + ...
	public LTIFilter(double[] ff, double[] fb) {
		setCoeffs(ff, fb);
	}

	
	public void setCoeffs(double[] ff, double[] fb) {
		inputMemory = new double[ff.length - 1];
		outputMemory = new double[fb.length - 1];
		this.feedForwardCoeffs = ff.clone();
		this.feedBackwardCoeffs = fb.clone();
	}

	// When all the memory is already allocated and the state of the filter
	// should be preserved, this is the method for you!!!
	public void setCoeffsSimple(double[] ff, double[] fb) {
		this.feedForwardCoeffs = ff.clone();
		this.feedBackwardCoeffs = fb.clone();
	}

	public static LTIFilter getFromCoefficients(double[] ff, double[] fb) {
		LTIFilter result = new LTIFilter(ff, fb);
		return result;
	}


	@Override
	public double getValue(double input) {

		// First calculate the direct (FIR) part
		double result = feedForwardCoeffs[0] * input;
		for (int i = 0; i < inputMemory.length; i++) {
			int a = inputWritePointer - i;
			int b = inputMemory.length;
			int index = (a >= 0 ? a % b : (b + a % b) % b);

			result += inputMemory[index] * feedForwardCoeffs[i + 1];
		}
		if (inputMemory.length > 0) {
			inputWritePointer = (inputWritePointer + 1) % inputMemory.length;
			inputMemory[inputWritePointer] = input;
		}

		// The calculate the recursive (IIR) part
		// The first coefficient is always a 1.0 or?
		for (int i = 0; i < outputMemory.length; i++) {
			int a = outputWritePointer - i;
			int b = outputMemory.length;
			int index = (a >= 0 ? a % b : (b + a % b) % b);
			result += outputMemory[index] * feedBackwardCoeffs[i + 1];
		}

		if (outputMemory.length > 0) {
			outputWritePointer = (outputWritePointer + 1) % outputMemory.length;
			outputMemory[outputWritePointer] = result;
		}

		return result;
	}

	public double[] getFeedBackCoeffs() {
		double[] result = new double[feedBackwardCoeffs.length];
		for (int i = 0; i < feedBackwardCoeffs.length; i++) {
			result[i] = -feedBackwardCoeffs[i];
		}
		result[0] = 1.0;
		return result;
	}

	public double[] getFeedForwardCoeffs() {
		return feedForwardCoeffs;
	}

}
