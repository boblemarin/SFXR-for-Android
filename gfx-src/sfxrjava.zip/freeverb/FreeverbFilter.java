//
// Copyright (c) 2010 Per Nyblom, Nyblom Software Sweden
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


package freeverb;


public class FreeverbFilter extends Filter {

	public double wet1 = 0.5;
	public double wet2 = 0.5;
	public double dry = 0.0;
	public double gain = 0.1;
	public int spread_factor = 23;
	public double postAmp = 0.5;
	public double damp = 0.2;
	public double room_size = 0.9;

	int[] leftNs;
	int[] rightNs;

	int[] leftAPNs;
	int[] rightAPNs;
	double leftAPg = 0.5;
	double rightAPg = 0.5;

	Filter[] combLFilters;
	Filter[] combRFilters;
	Filter[] allPassLFilters;
	Filter[] allPassRFilters;

	public FreeverbFilter() {
	}

	public void buildFilters() {
		leftAPNs = new int[] { 228, 556, 441, 341 };
		rightAPNs = new int[] { 228, 556, 441, 341 };

		leftNs = new int[] { 1887, 1617, 1491, 1422, 1277, 1356, 1386, 1188,
				1116 };
		rightNs = new int[] { 1887, 1617, 1491, 1422, 1277, 1356, 1386, 1188,
				1116 };

		// Calculate new n:s
		for (int i = 0; i < leftNs.length; i++) {
			leftNs[i] = (int) (leftNs[i]); // * n_factor);
			rightNs[i] = (int) (leftNs[i] + spread_factor); // n_spread_factor);
		}

		for (int i = 0; i < leftAPNs.length; i++) {
			leftAPNs[i] = (int) (leftAPNs[i]);
			rightAPNs[i] = (int) (leftAPNs[i] + spread_factor); // *
			// n_spread_factor);
		}

		// Create the comb filters
		combLFilters = new Filter[leftNs.length];
		combRFilters = new Filter[rightNs.length];
		for (int i = 0; i < combLFilters.length; i++) {
			combLFilters[i] = new MoorerLowpassFeedbackCombFilter(room_size,
					damp, leftNs[i]);
			combRFilters[i] = new MoorerLowpassFeedbackCombFilter(room_size,
					damp, rightNs[i]);
		}

		allPassLFilters = new Filter[leftAPNs.length];
		allPassRFilters = new Filter[rightAPNs.length];

		for (int i = 0; i < allPassLFilters.length; i++) {
			int n = leftAPNs[i];
			allPassLFilters[i] = new SparseLTIFilter(new int[] { 0, n },
					new double[] { -1, 1.0 + leftAPg }, new int[] { n },
					new double[] { leftAPg });
			n = rightAPNs[i];
			allPassRFilters[i] = new SparseLTIFilter(new int[] { 0, n },
					new double[] { -1, 1.0 + rightAPg }, new int[] { n },
					new double[] { rightAPg });
		}
	}


	@Override
	public double getValue(double input) {
		double outL = 0.0;

		// Accumulate comb filters in parallel
		for (int i = 0; i < combLFilters.length; i++) {
			outL += combLFilters[i].getValue(input);
		}

		for (int i = 0; i < allPassLFilters.length; i++) {
			outL = allPassLFilters[i].getValue(outL);
		}

		// outputs[0] = outL * wet1 + outR * wet2 + inputs[0] * dry;
		// outputs[1] = outR * wet1 + outL * wet2 + inputs[1] * dry;
		return outL;
	}


	@Override
	public void getValues(double[] inputs, double[] outputs) {

		double outL = 0.0;
		double outR = 0.0;

		double input = gain * (inputs[0] + inputs[1]);

		// Accumulate comb filters in parallel
		for (int i = 0; i < combLFilters.length; i++) {
			outL += combLFilters[i].getValue(input);
			outR += combRFilters[i].getValue(input);
		}

		for (int i = 0; i < allPassLFilters.length; i++) {
			outL = allPassLFilters[i].getValue(outL);
			outR = allPassRFilters[i].getValue(outR);
		}

		outputs[0] = postAmp * (outL * wet1 + outR * wet2 + inputs[0] * dry);
		outputs[1] = postAmp * (outR * wet1 + outL * wet2 + inputs[1] * dry);
	}


}
