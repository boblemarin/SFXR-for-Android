//
// Copyright (c) 2010 Per Nyblom, Nyblom Software Sweden
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


package freeverb;



public class SparseLTIFilter extends LTIFilter {

	int[] feedForwardDelays; // The delay for the feedForwardCoeffs ff[0] *
	// x[n -
	// fftime[0]] + ff[1] * x[n - fftime[1] + ...
	int[] feedBackwardDelays; // The delay for the feedBackwardCoeffs fb[0] *

	// y[n - fbtime[0]] + fb[1] * y[n - fbtime[1] +
	// ...

	int inputWritePointer = 0;
	int outputWritePointer = 0;

	public SparseLTIFilter() {
	}

	public SparseLTIFilter(int[] ffDelays, double[] ff, int[] fbDelays,
			double[] fb) {
		setData(ffDelays, ff, fbDelays, fb);
	}

	@Override
	public void setSampleRate(double sampleRate) {
		super.setSampleRate(sampleRate);
	}

	public static int maxInt(int... arr) {
		int result = Integer.MIN_VALUE;
		for (int i = 0; i < arr.length; i++) {
			result = Math.max(result, arr[i]);
		}
		return result;
	}

	void setData(int[] ffDelays, double[] ff, int[] fbDelays, double[] fb) {
		inputMemory = new double[Math.max(maxInt(ffDelays), 0) + 1];
		outputMemory = new double[Math.max(maxInt(fbDelays), 0) + 1];
		this.feedForwardCoeffs = ff.clone();
		this.feedBackwardCoeffs = fb.clone();
		this.feedForwardDelays = ffDelays.clone();
		this.feedBackwardDelays = fbDelays.clone();
	}

	public static void fill(double[] source, double[] result) {
		int n = Math.min(source.length, result.length);
		for (int i = 0; i < n; i++) {
			result[i] = source[i];
		}
	}
	
	void setOutputMemory(double[] data) {
		fill(data, outputMemory);
	}

	@Override
	public double getValue(double input) {

		double result = 0.0f;
		// First calculate the direct (Feed forward) part
		for (int i = 0; i < feedForwardDelays.length; i++) {
			int delay = feedForwardDelays[i];
			int a = inputWritePointer - delay;
			int b = inputMemory.length;
			int index = (a >= 0 ? a % b : (b + a % b) % b);

			double value;
			if (delay == 0) {
				value = input * feedForwardCoeffs[i];
			} else {
				value = inputMemory[index] * feedForwardCoeffs[i];
			}
			result += value;
			// println(this + " index: " + index + " value: " + value + " coeff:
			// " + feedForwardCoeffs[i]);
		}

		if (inputMemory.length > 0) {
			inputMemory[inputWritePointer] = input;
			inputWritePointer = (inputWritePointer + 1) % inputMemory.length;
		}

		// The calculate the recursive (Feed backward) part
		for (int i = 0; i < feedBackwardDelays.length; i++) {
			int delay = feedBackwardDelays[i];
			int a = outputWritePointer - delay;
			int b = outputMemory.length;
			int index = (a >= 0 ? a % b : (b + a % b) % b);
			result += outputMemory[index] * feedBackwardCoeffs[i];
		}

		if (outputMemory.length > 0) {
			outputMemory[outputWritePointer] = result;
			outputWritePointer = (outputWritePointer + 1) % outputMemory.length;
		}

		return result;
	}


	public double[] getFeedBackCoeffs() {
		// We have to build the "real" coefficients here since the filter is
		// sparse
		double[] result = new double[outputMemory.length];
		for (int i = 0; i < feedBackwardDelays.length; i++) {
			int delay = feedBackwardDelays[i];
			double coeff = feedBackwardCoeffs[i];
			result[delay] = -coeff;
		}
		result[0] = 1.0;
		return result;
	}

	public double[] getFeedForwardCoeffs() {
		// We have to build the "real" coefficients here since the filter is
		// sparse
		double[] result = new double[inputMemory.length];
		for (int i = 0; i < feedForwardDelays.length; i++) {
			int delay = feedForwardDelays[i];
			double coeff = feedForwardCoeffs[i];
			result[delay] = coeff;
		}
		return result;
	}


}
